HOST = ''
PORT = 50001
BFSZ = 65535
KEYWORD = 'MOMO'
SEPARATOR = ','
MOMO = '/usr/share/momo-2022.4.1_raspberry-pi-os_armv8/momo'
PATH_MOMO = '/usr/share/momo-2022.4.1_raspberry-pi-os_armv8/'
PATH_SERVICE = '/etc/systemd/system/momo.service'
